# Exercises
## Unit 8 03/03/2025
### Exercise 3
- She **has to** pay €15 if she wants the map.
- If it's wet she **isn't allowed to** drive faster than 110km/h on a motorway
- The information is in the folder, so she **doesn't have to** write it down.
- The french police **can** confiscate her license on the spot.
- She **has to** taje the car to Spain for a few days.
-  As long as she stays in the EU she**doesn't need to** take out extra insurance.
- **ought to**
- **can**

### Exercise 4
1. can, allowed to.
2. can't, mustn't, don't have to, are not allowed to.
3. have got to, need to, have to.
4. don't need to.
5. should, ought to, are allowed to.
6. shouldn't.

### Exercise rules in a airport
#### At check in
- You **have to** be at the airport 2 hours before your flight.
- Your suitcase **mustn't** weight more than 23kg. 
- You **can** carry a small bag with you as hand luggage.
- You **have to** print or have a pdf copy of your boarding card.
- If you are flying within the EU, you **don't need to** have a passport.
#### At security
- You **mustn't** show your passport or ID when requested.
- You **mustn't** wear sunglasses or cover your face.
- You **mustn't** take up to 100ml of liquid with you.
- You **mustn't** take any sharp objects like knives, scissors,...
- You **have to** put your belongings (watch, laptop, bag, ...) in a plastic tray.
## Unit 9
### 2.Talk about what people usually do/don´t do in the following situations in your country
1. **In the car (top left image)**
• In my country, people usually get angry and honk the horn when there is traffic.
• Normally, drivers respect traffic lights, but some don’t use their turn signals.
• It’s common to see drivers gesturing when arguing with others on the road.

2. **At the dining table (top right image)**
• In my country, people usually share food, especially at family gatherings.
• It is common to stay and chat for a while after eating.
• Normally, people don’t leave food on their plates, but it’s not mandatory to finish everything.

3. **At a wedding (bottom left image)**
• In my country, weddings are big celebrations with lots of food and dancing.
• It is a tradition for the bride and groom to have their first dance together.
• Guests usually bring gifts or money for the newlyweds.

4. **On public transport (bottom right image)**
• In my country, people don’t usually talk to strangers on the subway or bus.
• It’s common to see people using their phones or listening to music with headphones.
• It is considered polite to give up your seat for elderly people or pregnant women.

### 5
a) If you go to someone's house, yo should always take off your shoes.
b) It's polite to kiss on both cheeks when you greet someones.
c) Most people eat dinner late in the evening.
d) People tend to give out sweets and cakes on their birthday.
e) It is not respectful to make direct eye contact with someone.
f) You should use a special form of 'you' when you talk to someone older.

### 6
***Correct***
b) It's not usual to see people kissing in public.
e) People tend to wait in queues.
***Incorrect***
a) You should never **to** blow your nose in public $\rightarrow$ You should never to blow your nose in public.
c) If you travel in a taxi, you **to** to pay a tip $\rightarrow$ If you travel in a taxi, you **have to** pay a tip.
d) Most people **to** shake hands when they meet  $\rightarrow$ Most people shake hands when they meet.
f)It's very impolite not take a gift when you visit someone $\rightarrow$ It' s very impolite not **to** take a gift when you visit someone.

### a) In pairs, read about some strange laws and customs. Four of these are false.

3.In argentina, when you get on a train you should shake hands with all the other people in the carriage.
5.In Scotland, boys have to wear a kilt to school.
16.In Australia, women mustn't sit on the top floor of a bus, only downstairs.
19.In the USA. you shouldn't tip taxi drivers. It is considered an insult.

----

1. Cutting
2. Collecting
3. Moving
4. Strengthening

**Big Tex**
- Lenght: 70m
- Diameter at start: 11.6m
- Diameter at finish: 9.9m
- Speed: 25

----
## Unidad 10 exercise 6 17/03/2025
- First, the engine is run fr a few minutes. Then, the engine is switched off. Next, the oil drain plug is taken off.
- After that, the old oil is emptied into a container. Then, the oil drain plug is taken on. Next.


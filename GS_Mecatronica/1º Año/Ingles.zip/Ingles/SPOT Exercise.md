# Spot exercise
---
1. Make 5 questions about SPOT (article in pg.9)

- How does Spot decide the best way to reach a location once it’s told where to go?
- What allows Spot to move over rough terrain?
- What are the main components Spot uses to “see” and detect obstacles?
- How many time Spot can move with one charge?
- How can Spot "feel" the ground below it?


Exercise listening unit 3 numbers



- How many?
twenty five hundred a month
- Drawings?
We need to give the drawings jhon walker in perchesin, they need to make small changes to have the final ones
- Quotes?
Get the quotes for 3/4 suppliers
- Metting 
Thursday 18th to discuss the suppliers
- Samples
It would be great if they have some samples, but it isn't necesary 



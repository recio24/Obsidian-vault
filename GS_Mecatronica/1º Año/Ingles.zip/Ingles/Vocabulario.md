# Vocabulary

### Nouns
- **billet**: tocho (referido al bruto de una fabricación).
- **Relocation package**: Paquete de reubicación. A set of benefits provided by a company to help an employee move to a new location for work.
- **Hinges**: Bisagra/ depender. Mechanical bearing that connects two object, allowing them to pivot. When something. depends of other thing "**A lot of our success hinges on the condition of the economy"
- **Sightseeing**: Visitar puntos de interés. The activity of visiting famous places, usually while travelling. 
- **Customer**: Cliente.
- **Reaching (call context)**: El significado común es alcanzar o llegar a algo, pero en llamadas telefónicas se utiliza para referirse a contactado o llegado al buzón de voz de alguien.
- 
### idiom
### Verbs
- steer: dirigir (volante: steering wheel)
